#Coders by Nikolasi
from Tools.Directories import fileExists
from Tools.LoadPixmap import LoadPixmap 
from Components.Pixmap import Pixmap 
from .Renderer import Renderer
from enigma import eServiceCenter, eServiceReference, iServiceInformation, iPlayableService, eDVBFrontendParametersSatellite, eDVBFrontendParametersCable 
from enigma import ePixmap, eTimer 
from Tools.Directories import fileExists, SCOPE_SKIN_IMAGE, SCOPE_CURRENT_SKIN, resolveFilename 
from Components.config import config
from Components.Converter.Poll import Poll

class PicEmu2(Renderer, Poll):
	__module__ = __name__
	searchPaths = ('/usr/share/enigma2/BlackSPA/modeldu/%s/', '/media/hdd/%s/',  '/media/usb/%s/', '/media/sdb2/%s/')
	
	def __init__(self):
		Poll.__init__(self)
		Renderer.__init__(self)
		self.path = 'emu'
		self.nameCache = {}
		self.pngname = ''
		self.picon_default = "/usr/share/enigma2/BlackSPA/modeldu/emu/picon_default.png"
		
	def applySkin(self, desktop, parent):
		attribs = []
		for (attrib, value,) in self.skinAttributes:
			if (attrib == 'path'):
				self.path = value
			elif (attrib == 'picon_default'):
				self.picon_default = value
			else:
				attribs.append((attrib, value))
				
		self.skinAttributes = attribs
		return Renderer.applySkin(self, desktop, parent)
		
	GUI_WIDGET = ePixmap
	
	def changed(self, what):
		self.poll_interval = 2000
		self.poll_enabled = True
		control = 0 
		if self.instance:
			pngname = ''
			if (what[0] != self.CHANGED_CLEAR):
				cfgfile = "/etc/.ActiveCamd"
				sname = ""
				service = self.source.service
				if service:
					info = (service and service.info())
					if info:
						caids = info.getInfoObject(iServiceInformation.sCAIDs)
						try:
							f = open(cfgfile, "r")
							content = f.read()
							f.close()
						except:
							content = ""
						line = content.lower()
						if ("cccam" in line):
							sname = "CCcam"
						elif ("mgcamd" in line):
							sname = "Mgcamd"
						elif ("oscam" in line):
							sname = "OScam"
						elif ("wicardd" in line):
							sname = "Wicardd"
						elif ("gbox" in line):
							sname = "Gbox"
						elif ("camd3" in line):
							sname = "Camd3"
						elif ("ncam" in line):
							sname = "Ncam"
						elif ("sbox" in line):
							sname = "Sbox"
						if caids:
							if (len(caids) > 0):
								for caid in caids:
									caid = self.int2hex(caid)
									if (len(caid) == 3):
										caid = ("0%s" % caid)
									caid = caid[:2]
									caid = caid.upper()
									if (caid != "") and (sname == ""):
										sname = "Unknown"

				pngname = self.nameCache.get(sname, '')
				if (pngname == ''):
					pngname = self.findPicon(sname)
					if (pngname != ''):
						self.nameCache[sname] = pngname
					
			if (pngname == ''):
				pngname = self.nameCache.get('Fta', '')
				if (pngname == ''):
					pngname = self.findPicon('Fta')
					if (pngname == ''):
						tmp = resolveFilename(SCOPE_CURRENT_SKIN, 'picon_default.png')
						if fileExists(tmp):
							pngname = tmp
						else:
							pngname = resolveFilename(SCOPE_SKIN_IMAGE, 'skin_default/picon_default.png')
						self.nameCache['default'] = pngname
			if (self.pngname != pngname):
				self.pngname = pngname
				self.instance.setScale(1)
				self.instance.setPixmapFromFile(self.pngname)


	def int2hex(self, int):
		return ("%x" % int)

	def findPicon(self, serviceName):
 
		for path in self.searchPaths:
			pngname = (((path % self.path) + serviceName) + '.png')
			if fileExists(pngname):
				return pngname
				
		return ''
